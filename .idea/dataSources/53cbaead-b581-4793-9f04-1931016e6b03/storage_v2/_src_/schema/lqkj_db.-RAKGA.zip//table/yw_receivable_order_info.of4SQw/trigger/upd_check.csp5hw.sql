create definer = lqkj@`%` trigger upd_check
    before update
    on yw_receivable_order_info
    for each row
BEGIN
INSERT INTO yw_receivable_order_info_copy SELECT * FROM yw_receivable_order_info where ord_id=old.ord_id;
END;

