create definer = lqkj@`%` trigger upd_boxing_record_copy1
    after update
    on yw_project_boxing_info_autoput_detail
    for each row
BEGIN
 if old.state=1 and new.state=0 then
  INSERT INTO yw_project_boxing_info_his(model_id,box_id,box_code,order_id,plan_id,win_id,tran_date,gw_id,pcb_sn,state,up_date)
VALUES(old.model_id,old.box_id,old.box_code,old.order_id,old.plan_id,old.win_id,old.tran_date,old.gw_id,old.pcb_sn,old.state,now());
end if;
END;

