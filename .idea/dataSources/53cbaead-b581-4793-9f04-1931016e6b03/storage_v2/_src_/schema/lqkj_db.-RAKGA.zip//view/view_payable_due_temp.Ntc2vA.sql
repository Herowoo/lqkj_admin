create definer = lqkj@`%` view view_payable_due_temp as
select `paid_info`.`code_cre_id`                                                                     AS `code_cre_id`,
       `paid_info`.`sum_amo_money`                                                                   AS `sum_amo_money`,
       `paid_info`.`out_true_money`                                                                  AS `out_true_money`,
       if(((ifnull(`due_sum_paymoney`.`due_sum_money`, 0) - ifnull(`paid_info`.`out_true_money`, 0)) < 0), 0,
          (ifnull(`due_sum_paymoney`.`due_sum_money`, 0) - ifnull(`paid_info`.`out_true_money`, 0))) AS `due_paymoney`
from ((select `get_sum`.`code_cre_id`          AS `code_cre_id`,
              `get_sum`.`sum_amo_money`        AS `sum_amo_money`,
              ifnull(`out_sum`.`out_money`, 0) AS `out_true_money`
       from ((select `view_payable_get`.`code_cre_id`         AS `code_cre_id`,
                     sum(`view_payable_get`.`code_amo_money`) AS `sum_amo_money`
              from `lqkj_db`.`view_payable_get`
              group by `view_payable_get`.`code_cre_id`) `get_sum`
                left join `lqkj_db`.`view_payable_out` `out_sum`
                          on ((`get_sum`.`code_cre_id` = `out_sum`.`code_cre_id`)))) `paid_info`
         left join (select `view_payable_get`.`code_cre_id` AS `code_cre_id`,
                           `tb_due`.`due_sum_money`         AS `due_sum_money`
                    from `lqkj_db`.`view_payable_get`
                             join (select `view_payable_get`.`code_cre_id`                    AS `code_cre_id`,
                                          ifnull(sum(`view_payable_get`.`code_amo_money`), 0) AS `due_sum_money`
                                   from `lqkj_db`.`view_payable_get`
                                   where (`view_payable_get`.`due_date` < now())
                                   group by `view_payable_get`.`code_cre_id`) `tb_due`
                    where (`view_payable_get`.`code_cre_id` = `tb_due`.`code_cre_id`)) `due_sum_paymoney`
                   on ((`paid_info`.`code_cre_id` = `due_sum_paymoney`.`code_cre_id`)));

