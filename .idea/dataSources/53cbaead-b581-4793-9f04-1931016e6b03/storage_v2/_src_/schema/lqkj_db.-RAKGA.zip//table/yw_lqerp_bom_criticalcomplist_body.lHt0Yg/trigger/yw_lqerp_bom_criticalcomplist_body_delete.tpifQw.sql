create definer = lqkj@`%` trigger yw_lqerp_bom_criticalcomplist_body_delete
    before delete
    on yw_lqerp_bom_criticalcomplist_body
    for each row
BEGIN
INSERT INTO yw_lqerp_bom_criticalcomplist_body_his SELECT * FROM yw_lqerp_bom_criticalcomplist_body where id=old.id;
END;

