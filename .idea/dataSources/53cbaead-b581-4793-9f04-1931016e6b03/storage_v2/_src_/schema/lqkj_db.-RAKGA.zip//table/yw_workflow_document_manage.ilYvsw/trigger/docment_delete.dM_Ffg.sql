create definer = lqkj@`%` trigger docment_delete
    after delete
    on yw_workflow_document_manage
    for each row
BEGIN
INSERT INTO yw_workflow_document_manage_his SELECT * FROM yw_workflow_document_manage where id=old.id;
END;

