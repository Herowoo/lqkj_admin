create definer = lqkj@`%` view view_receipt_one as
select `view_receipt_detail`.`cre_id`                                                                            AS `cre_id`,
       `view_receipt_detail`.`cus_name`                                                                          AS `cus_name`,
       `view_receipt_detail`.`ass_period`                                                                        AS `ass_period`,
       `view_receipt_detail`.`sal_person`                                                                        AS `sal_person`,
       `view_receipt_detail`.`order_id`                                                                          AS `order_id`,
       `view_receipt_detail`.`order_detail_info`                                                                 AS `order_detail_info`,
       `view_receipt_detail`.`order_adv_payment`                                                                 AS `order_adv_payment`,
       `view_receipt_detail`.`order_qua_deposit`                                                                 AS `order_qua_deposit`,
       `view_receipt_detail`.`order_bao_term`                                                                    AS `order_bao_term`,
       `view_receipt_detail`.`order_ded_money`                                                                   AS `order_ded_money`,
       max(`view_receipt_detail`.`code_date`)                                                                    AS `code_date`,
       sum(`view_receipt_detail`.`code_amo_money`)                                                               AS `all_code_amo_money`,
       (max(`view_receipt_detail`.`code_date`) +
        interval `view_receipt_detail`.`ass_period` day)                                                         AS `mat_date`,
       (to_days(now()) - to_days((max(`view_receipt_detail`.`code_date`) +
                                  interval `view_receipt_detail`.`ass_period` day)))                             AS `exc_date`,
       (max(`view_receipt_detail`.`code_date`) +
        interval `view_receipt_detail`.`order_bao_term` day)                                                     AS `bao_mat_date`,
       (to_days(now()) - to_days((max(`view_receipt_detail`.`code_date`) +
                                  interval `view_receipt_detail`.`order_bao_term` day)))                         AS `bao_exc_date`
from `lqkj_db`.`view_receipt_detail`
where (`view_receipt_detail`.`CODE` = '1')
group by `view_receipt_detail`.`order_id`;

