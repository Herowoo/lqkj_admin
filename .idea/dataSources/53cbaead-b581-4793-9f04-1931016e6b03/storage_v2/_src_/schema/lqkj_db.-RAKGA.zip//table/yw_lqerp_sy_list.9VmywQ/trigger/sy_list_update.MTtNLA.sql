create definer = lqkj@`%` trigger SY_LIST_UPDATE
    before update
    on yw_lqerp_sy_list
    for each row
BEGIN
INSERT INTO yw_lqerp_sy_list_his(old_id,tran_date,user_id,bom_no,prd_name,pcb_version,install_version,plan_no,cust_name,use_zone,prd_num,change_flag,gw_id_relation,pilot_test_report,prodtest_log,metertest_log,prd_picture,deli_Insp_report,pack_picture,state,note) SELECT id,tran_date,user_id,bom_no,prd_name,pcb_version,install_version,plan_no,cust_name,use_zone,prd_num,change_flag,gw_id_relation,pilot_test_report,prodtest_log,metertest_log,prd_picture,deli_Insp_report,pack_picture,state,note FROM yw_lqerp_sy_list where id=old.id;
END;

