create definer = lqkj@`%` trigger delete_data_bak
    after delete
    on yw_project_gwid_detail
    for each row
BEGIN
INSERT INTO yw_project_gwid_detail_his(gw_id, proj_id, gl_id, state)
VALUES(old.gw_id, old.proj_id, old.gl_id, old.state);
END;

