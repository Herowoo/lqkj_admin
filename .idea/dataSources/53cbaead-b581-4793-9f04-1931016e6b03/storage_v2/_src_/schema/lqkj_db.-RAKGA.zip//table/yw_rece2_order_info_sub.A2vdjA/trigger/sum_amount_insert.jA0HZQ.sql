create definer = lqkj@`%` trigger sum_amount_insert
    after insert
    on yw_rece2_order_info_sub
    for each row
    update yw_rece2_order_info set send_amount=(select sum(order_amount) from yw_rece2_order_info_sub where order_id=NEW.order_id) where order_id=NEW.order_id;

