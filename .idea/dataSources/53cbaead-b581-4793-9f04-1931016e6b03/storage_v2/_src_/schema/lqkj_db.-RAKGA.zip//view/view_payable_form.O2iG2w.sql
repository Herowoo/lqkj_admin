create definer = lqkj@`%` view view_payable_form as
select `due_temp`.`code_cre_id`                                                                 AS `code_cre_id`,
       `fac`.`fac_name`                                                                         AS `fac_name`,
       `fac`.`ass_period`                                                                       AS `ass_period`,
       `due_temp`.`sum_amo_money`                                                               AS `sum_amo_money`,
       `due_temp`.`out_true_money`                                                              AS `out_true_money`,
       (`due_temp`.`sum_amo_money` - `due_temp`.`out_true_money`)                               AS `unpay_money`,
       `due_temp`.`due_paymoney`                                                                AS `due_paymoney`,
       ((`due_temp`.`sum_amo_money` - `due_temp`.`due_paymoney`) - `due_temp`.`out_true_money`) AS `undue_paymoney`
from (`lqkj_db`.`yw_payable_factory_info` `fac`
         join `lqkj_db`.`view_payable_due_temp` `due_temp`)
where (`fac`.`cre_id` = `due_temp`.`code_cre_id`)
group by `due_temp`.`code_cre_id`;

