create
    definer = lqkj@`%` function getseqvalue(seqname varchar(50)) returns varchar(50)
BEGIN
	DECLARE retval varchar(50);
  SELECT IFNULL(current_val, 0) INTO retval FROM sys_sequence WHERE seq_name = seqname for update;  
  UPDATE sys_sequence SET current_val = current_val + increment_val WHERE seq_name = seqname;
	RETURN @retval;
END;

