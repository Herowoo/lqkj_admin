create definer = lqkj@`%` view view_bill_select_tmp as
select `tb_head`.`id`                              AS `id`,
       `tb_head`.`head_id`                         AS `head_id`,
       `tb_head`.`proid`                           AS `proid`,
       `tb_head`.`order_type`                      AS `order_type`,
       `tb_head`.`insert_time`                     AS `insert_time`,
       `tb_head`.`order_number`                    AS `order_number`,
       `tb_head`.`plan_number`                     AS `plan_number`,
       `tb_head`.`customer_name`                   AS `customer_name`,
       `tb_head`.`product_name`                    AS `product_name`,
       `tb_head`.`specification`                   AS `specification`,
       `tb_head`.`quantity`                        AS `quantity`,
       `tb_head`.`delivery_date`                   AS `delivery_date`,
       `tb_head`.`salesman`                        AS `salesman`,
       `tb_head`.`area`                            AS `area`,
       `tb_head`.`special_claim`                   AS `special_claim`,
       `tb_head`.`special_care`                    AS `special_care`,
       `tb_head`.`state`                           AS `state`,
       ifnull(`tb_require`.`require_value`, '未填写') AS `require_value`
from (`lqkj_db`.`yw_bill_review_form_head` `tb_head`
         left join (select `lqkj_db`.`yw_bill_review_form_body`.`id`            AS `id`,
                           `lqkj_db`.`yw_bill_review_form_body`.`head_id`       AS `head_id`,
                           `lqkj_db`.`yw_bill_review_form_body`.`require_value` AS `require_value`
                    from `lqkj_db`.`yw_bill_review_form_body`
                    where `lqkj_db`.`yw_bill_review_form_body`.`id` in
                          (select max(`lqkj_db`.`yw_bill_review_form_body`.`id`)
                           from `lqkj_db`.`yw_bill_review_form_body`
                           where ((`lqkj_db`.`yw_bill_review_form_body`.`name_id` = 1) and
                                  (`lqkj_db`.`yw_bill_review_form_body`.`row_id` = 0))
                           group by `lqkj_db`.`yw_bill_review_form_body`.`head_id`,
                                    `lqkj_db`.`yw_bill_review_form_body`.`name_id`,
                                    `lqkj_db`.`yw_bill_review_form_body`.`row_id`)) `tb_require`
                   on ((`tb_head`.`head_id` = `tb_require`.`head_id`)));

