create definer = lqkj@`%` view view_receipt_detail as
select `lqkj_db`.`yw_receivable_customer_info`.`cre_id`          AS `cre_id`,
       `lqkj_db`.`yw_receivable_customer_info`.`cus_name`        AS `cus_name`,
       `lqkj_db`.`yw_receivable_order_info`.`order_assperiod`    AS `ass_period`,
       `lqkj_db`.`yw_receivable_salesperson_info`.`sal_person`   AS `sal_person`,
       `lqkj_db`.`yw_receivable_order_info`.`order_id`           AS `order_id`,
       `lqkj_db`.`yw_receivable_order_info`.`order_detail_info`  AS `order_detail_info`,
       `lqkj_db`.`yw_receivable_order_info`.`order_tran_date`    AS `order_tran_date`,
       `lqkj_db`.`yw_receivable_order_info`.`order_upd_date`     AS `order_upd_date`,
       `lqkj_db`.`yw_receivable_order_info`.`order_enter_person` AS `order_enter_person`,
       `lqkj_db`.`yw_receivable_order_info`.`order_cre_id`       AS `order_cre_id`,
       `lqkj_db`.`yw_receivable_order_info`.`order_sal_id`       AS `order_sal_id`,
       `lqkj_db`.`yw_receivable_order_info`.`order_adv_payment`  AS `order_adv_payment`,
       `lqkj_db`.`yw_receivable_order_info`.`order_qua_deposit`  AS `order_qua_deposit`,
       `lqkj_db`.`yw_receivable_order_info`.`order_bao_term`     AS `order_bao_term`,
       `lqkj_db`.`yw_receivable_order_info`.`order_ded_money`    AS `order_ded_money`,
       `lqkj_db`.`yw_receivable_order_info`.`order_remarks`      AS `order_remarks`,
       `lqkj_db`.`yw_receivable_order_info`.`order_state`        AS `order_state`,
       `lqkj_db`.`yw_receivable_invoice_info`.`CODE`             AS `CODE`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_pay_type`    AS `code_pay_type`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_num`         AS `code_num`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_date`        AS `code_date`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_amo_money`   AS `code_amo_money`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_annex`       AS `code_annex`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_hand_date`   AS `code_hand_date`
from (((`lqkj_db`.`yw_receivable_order_info` join `lqkj_db`.`yw_receivable_customer_info` on ((
        `lqkj_db`.`yw_receivable_order_info`.`order_cre_id` =
        `lqkj_db`.`yw_receivable_customer_info`.`cre_id`))) join `lqkj_db`.`yw_receivable_salesperson_info` on ((
        `lqkj_db`.`yw_receivable_order_info`.`order_sal_id` = `lqkj_db`.`yw_receivable_salesperson_info`.`sal_id`)))
         join `lqkj_db`.`yw_receivable_invoice_info` on ((`lqkj_db`.`yw_receivable_order_info`.`order_id` =
                                                          `lqkj_db`.`yw_receivable_invoice_info`.`code_order_id`)))
where ((`lqkj_db`.`yw_receivable_order_info`.`order_state` = '0') and
       (`lqkj_db`.`yw_receivable_invoice_info`.`code_state` = '1'));

