create definer = lqkj@`%` trigger del_check
    before delete
    on yw_receivable_order_info
    for each row
BEGIN
INSERT INTO yw_receivable_order_info_copy SELECT * FROM yw_receivable_order_info where ord_id=old.ord_id;
END;

