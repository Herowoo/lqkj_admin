create view view_document_code_value as
select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
       `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`
from `lqkj_db`.`yw_workflow_document_classtype`
where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 1)
union
select concat_ws('_', `r1`.`class_spell`, `r2`.`class_spell`) AS `CONCAT_WS('_', r1.class_spell, r2.class_spell)`,
       concat_ws('_', `r1`.`class_name`, `r2`.`class_name`)   AS `CONCAT_WS('_', r1.class_name, r2.class_name)`
from (select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
             `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`
      from `lqkj_db`.`yw_workflow_document_classtype`
      where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 1)) `r1`
         join (select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_top`   AS `class_top`
               from `lqkj_db`.`yw_workflow_document_classtype`
               where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 2)) `r2`
where (`r2`.`class_top` = `r1`.`class_spell`)
union
select concat_ws('_', concat_ws('_', `r1`.`class_spell`, `r2`.`class_spell`), `r3`.`class_spell`) AS `Name_exp_5`,
       concat_ws('_', concat_ws('_', `r1`.`class_name`, `r2`.`class_name`), `r3`.`class_name`)    AS `Name_exp_6`
from (select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
             `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`
      from `lqkj_db`.`yw_workflow_document_classtype`
      where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 1)) `r1`
         join (select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_top`   AS `class_top`
               from `lqkj_db`.`yw_workflow_document_classtype`
               where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 2)) `r2`
         join (select `lqkj_db`.`yw_workflow_document_classtype`.`class_spell` AS `class_spell`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_name`  AS `class_name`,
                      `lqkj_db`.`yw_workflow_document_classtype`.`class_top`   AS `class_top`
               from `lqkj_db`.`yw_workflow_document_classtype`
               where (`lqkj_db`.`yw_workflow_document_classtype`.`class_rank` = 3)) `r3`
where ((`r2`.`class_top` = `r1`.`class_spell`) and (`r3`.`class_top` = `r2`.`class_spell`));

