create definer = lqkj@`%` view view_project_info as
select `lqkj_db`.`yw_project_boxing_info`.`model_id`  AS `model_id`,
       `lqkj_db`.`yw_project_boxing_info`.`box_code`  AS `box_code`,
       `lqkj_db`.`yw_project_boxing_info`.`box_id`    AS `box_id`,
       `lqkj_db`.`yw_project_boxing_info`.`order_id`  AS `order_id`,
       `lqkj_db`.`yw_project_boxing_info`.`plan_id`   AS `plan_id`,
       `lqkj_db`.`yw_project_boxing_info`.`win_id`    AS `win_id`,
       `lqkj_db`.`yw_project_boxing_info`.`prod_line` AS `prod_line`,
       `lqkj_db`.`yw_project_boxing_info`.`tran_date` AS `tran_date`,
       `lqkj_db`.`yw_project_boxing_info`.`gw_id`     AS `gw_id`,
       `lqkj_db`.`yw_project_boxing_info`.`pcb_sn`    AS `pcb_sn`,
       `lqkj_db`.`yw_project_boxing_info`.`state`     AS `state`,
       `lqkj_db`.`yw_project_info`.`spc_name`         AS `spc_name`
from (`lqkj_db`.`yw_project_boxing_info`
         join `lqkj_db`.`yw_project_info`)
where (`lqkj_db`.`yw_project_boxing_info`.`order_id` = convert(`lqkj_db`.`yw_project_info`.`order_id` using utf8mb4))
order by `lqkj_db`.`yw_project_boxing_info`.`tran_date` desc;

