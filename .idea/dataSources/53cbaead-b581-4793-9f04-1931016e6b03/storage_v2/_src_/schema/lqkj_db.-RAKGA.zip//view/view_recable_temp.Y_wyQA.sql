create definer = lqkj@`%` view view_recable_temp as
select `tb`.`order_cre_id`                                          AS `order_cre_id`,
       if((sum(`tb`.`temp_money`) <= 0), 0, sum(`tb`.`temp_money`)) AS `due_rec_money`
from (select `view_recable_open`.`order_cre_id`        AS `order_cre_id`,
             sum(`view_recable_open`.`code_amo_money`) AS `temp_money`
      from `lqkj_db`.`view_recable_open`
      where (`view_recable_open`.`due_date` <= now())
      group by `view_recable_open`.`order_cre_id`
      union all
      select `view_recable_rece`.`order_cre_id`                     AS `order_cre_id`,
             concat('-', sum(`view_recable_rece`.`code_amo_money`)) AS `temp_money`
      from `lqkj_db`.`view_recable_rece`
      group by `view_recable_rece`.`order_cre_id`) `tb`
group by `tb`.`order_cre_id`;

