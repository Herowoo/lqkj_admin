create definer = lqkj@`%` trigger yw_lqerp_bom_criticalcomplist_head_delete
    before delete
    on yw_lqerp_bom_criticalcomplist_head
    for each row
BEGIN
INSERT INTO yw_lqerp_bom_criticalcomplist_head_his SELECT * FROM yw_lqerp_bom_criticalcomplist_head where id=old.id;
END;

