create definer = lqkj@`%` trigger insert_calc_work_time
    before insert
    on yw_adm_personnel_list
    for each row
    SET NEW.work_time=CONVERT(DATEDIFF(now(),NEW.induc_date)/365,DECIMAL(10,2));

