create definer = lqkj@`%` view v_department_month_report as
select `s`.`USER_NAME`           AS `姓名`,
       `so`.`ORG_NAME`           AS `部门`,
       `yd`.`DICT_TARGET`        AS `岗位`,
       `h`.`tran_date`           AS `提交时间`,
       `h`.`month_id`            AS `月份`,
       `h`.`month_start`         AS `开始时间`,
       `h`.`month_end`           AS `结束时间`,
       `b`.`plan_matter`         AS `计划完成事项`,
       `b`.`for_problem`         AS `针对的问题`,
       `b`.`plan_finish_date`    AS `计划完成时间`,
       `b`.`completion_progress` AS `完成进度`,
       `b`.`true_finish_date`    AS `实际完成时间`,
       `b`.`improve_action`      AS `改善措施`
from `lqkj_db`.`yw_report_section_month_head` `h`
         join `lqkj_db`.`yw_report_section_month_body` `b`
         join `lqkj_db`.`sys_user` `s`
         join `lqkj_db`.`sys_org` `so`
         join `lqkj_db`.`sys_ywty_dict` `yd`
where ((`b`.`head_id` = `h`.`id`) and (`h`.`user_id` = `s`.`USER_ID`) and (`h`.`org_id` = `so`.`ORG_ID`) and
       (`s`.`STATION` = `yd`.`DICT_CODE`) and (`yd`.`DICT_NAME` = 'POSITION'));

