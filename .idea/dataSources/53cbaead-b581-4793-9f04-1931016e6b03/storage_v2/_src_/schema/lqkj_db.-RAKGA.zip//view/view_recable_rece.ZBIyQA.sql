create definer = lqkj@`%` view view_recable_rece as
select `order_info`.`order_cre_id`  AS `order_cre_id`,
       `invo_info`.`code_order_id`  AS `code_order_id`,
       `invo_info`.`CODE`           AS `CODE`,
       `invo_info`.`code_num`       AS `code_num`,
       `invo_info`.`code_date`      AS `code_date`,
       `invo_info`.`code_amo_money` AS `code_amo_money`
from (`lqkj_db`.`yw_receivable_invoice_info` `invo_info`
         join (select `lqkj_db`.`yw_receivable_order_info`.`order_cre_id`    AS `order_cre_id`,
                      `lqkj_db`.`yw_receivable_order_info`.`order_id`        AS `order_id`,
                      `lqkj_db`.`yw_receivable_order_info`.`order_assperiod` AS `order_assperiod`
               from `lqkj_db`.`yw_receivable_order_info`) `order_info`)
where ((`invo_info`.`code_order_id` = `order_info`.`order_id`) and (`invo_info`.`CODE` = '2') and
       (`invo_info`.`code_state` = '1'));

