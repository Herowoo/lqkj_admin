create definer = lqkj@`%` trigger update_calc_age
    before update
    on yw_adm_personnel_list
    for each row
    SET NEW.age=YEAR (now()) - YEAR (substring(NEW.identi_numer, 7, 8));

