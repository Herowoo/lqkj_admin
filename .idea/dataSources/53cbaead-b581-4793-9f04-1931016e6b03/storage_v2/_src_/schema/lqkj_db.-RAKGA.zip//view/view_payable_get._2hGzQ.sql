create definer = lqkj@`%` view view_payable_get as
select `lqkj_db`.`yw_payable_invoice_info`.`code_cre_id`               AS `code_cre_id`,
       `lqkj_db`.`yw_payable_invoice_info`.`CODE`                      AS `CODE`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_amo_money`            AS `code_amo_money`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_date`                 AS `code_date`,
       `lqkj_db`.`yw_payable_factory_info`.`cre_id`                    AS `cre_id`,
       `lqkj_db`.`yw_payable_factory_info`.`ass_period`                AS `ass_period`,
       (`lqkj_db`.`yw_payable_invoice_info`.`code_date` +
        interval `lqkj_db`.`yw_payable_factory_info`.`ass_period` day) AS `due_date`
from (`lqkj_db`.`yw_payable_invoice_info`
         join `lqkj_db`.`yw_payable_factory_info`)
where ((`lqkj_db`.`yw_payable_invoice_info`.`code_state` = '1') and
       (`lqkj_db`.`yw_payable_invoice_info`.`CODE` = '1') and
       (`lqkj_db`.`yw_payable_factory_info`.`cre_id` = `lqkj_db`.`yw_payable_invoice_info`.`code_cre_id`));

