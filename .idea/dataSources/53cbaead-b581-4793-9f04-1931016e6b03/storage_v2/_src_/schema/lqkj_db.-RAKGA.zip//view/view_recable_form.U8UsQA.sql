create definer = lqkj@`%` view view_recable_form as
select `tb_due_info`.`order_cre_id`                                                                AS `order_cre_id`,
       `lqkj_db`.`yw_receivable_customer_info`.`cus_name`                                          AS `cus_name`,
       `tb_due_info`.`open_money`                                                                  AS `open_money`,
       `tb_due_info`.`rece_money`                                                                  AS `rece_money`,
       (`tb_due_info`.`open_money` - `tb_due_info`.`rece_money`)                                   AS `unrece_money`,
       `tb_due_info`.`due_rec_money`                                                               AS `due_rec_money`,
       ((`tb_due_info`.`open_money` - `tb_due_info`.`rece_money`) - `tb_due_info`.`due_rec_money`) AS `undue_rec_money`
from ((select `view_recable_temp`.`order_cre_id`  AS `order_cre_id`,
              ifnull(`tb_open`.`open_money`, 0)   AS `open_money`,
              ifnull(`tb_rece`.`rece_money`, 0)   AS `rece_money`,
              `view_recable_temp`.`due_rec_money` AS `due_rec_money`
       from ((`lqkj_db`.`view_recable_temp` left join (select `view_recable_open`.`order_cre_id`        AS `order_cre_id`,
                                                              sum(`view_recable_open`.`code_amo_money`) AS `open_money`
                                                       from `lqkj_db`.`view_recable_open`
                                                       group by `view_recable_open`.`order_cre_id`) `tb_open` on ((`view_recable_temp`.`order_cre_id` = `tb_open`.`order_cre_id`)))
                left join (select `view_recable_rece`.`order_cre_id`        AS `order_cre_id`,
                                  sum(`view_recable_rece`.`code_amo_money`) AS `rece_money`
                           from `lqkj_db`.`view_recable_rece`
                           group by `view_recable_rece`.`order_cre_id`) `tb_rece`
                          on ((`view_recable_temp`.`order_cre_id` = `tb_rece`.`order_cre_id`)))) `tb_due_info`
         join `lqkj_db`.`yw_receivable_customer_info`)
where (`lqkj_db`.`yw_receivable_customer_info`.`cre_id` = `tb_due_info`.`order_cre_id`);

