create definer = lqkj@`%` view view_bill_audit as
select `lqkj_db`.`yw_bill_review_form_head`.`id`     AS `id`,
       `lqkj_db`.`yw_bill_audit_info`.`id`           AS `audit_id`,
       `lqkj_db`.`yw_bill_audit_info`.`audit_billid` AS `audit_billid`,
       `lqkj_db`.`yw_bill_audit_info`.`audit_state`  AS `audit_state`
from (`lqkj_db`.`yw_bill_audit_info`
         join `lqkj_db`.`yw_bill_review_form_head`)
where ((`lqkj_db`.`yw_bill_review_form_head`.`head_id` = `lqkj_db`.`yw_bill_audit_info`.`audit_billid`) and
       (`lqkj_db`.`yw_bill_audit_info`.`audit_state` = '0'))
group by `lqkj_db`.`yw_bill_audit_info`.`audit_billid`;

