create definer = lqkj@`%` view view_payable_out as
select `lqkj_db`.`yw_payable_invoice_info`.`code_cre_id`         AS `code_cre_id`,
       `lqkj_db`.`yw_payable_invoice_info`.`CODE`                AS `CODE`,
       sum(`lqkj_db`.`yw_payable_invoice_info`.`code_amo_money`) AS `out_money`
from `lqkj_db`.`yw_payable_invoice_info`
where (`lqkj_db`.`yw_payable_invoice_info`.`CODE` = '2')
group by `lqkj_db`.`yw_payable_invoice_info`.`code_cre_id`;

