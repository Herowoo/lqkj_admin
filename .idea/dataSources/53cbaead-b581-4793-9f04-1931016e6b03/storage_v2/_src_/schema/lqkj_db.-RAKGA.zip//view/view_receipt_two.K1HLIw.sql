create definer = lqkj@`%` view view_receipt_two as
select `view_receipt_detail`.`cre_id`              AS `cre_id`,
       `view_receipt_detail`.`cus_name`            AS `cus_name`,
       `view_receipt_detail`.`ass_period`          AS `ass_period`,
       `view_receipt_detail`.`sal_person`          AS `sal_person`,
       `view_receipt_detail`.`order_id`            AS `order_id`,
       `view_receipt_detail`.`order_detail_info`   AS `order_detail_info`,
       max(`view_receipt_detail`.`code_date`)      AS `code_date`,
       sum(`view_receipt_detail`.`code_amo_money`) AS `all_code_amo_money`
from `lqkj_db`.`view_receipt_detail`
where (`view_receipt_detail`.`CODE` = '2')
group by `view_receipt_detail`.`order_id`;

