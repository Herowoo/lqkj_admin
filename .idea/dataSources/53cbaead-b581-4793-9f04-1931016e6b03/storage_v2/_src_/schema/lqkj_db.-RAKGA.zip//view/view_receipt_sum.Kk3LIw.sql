create definer = lqkj@`%` view view_receipt_sum as
select concat(now())                                                                                       AS `end_time`,
       concat('所有客户')                                                                                      AS `all_cus`,
       sum(`view_receipt_all`.`total_sal_money`)                                                           AS `sum_sal_money`,
       (select sum(`view_receipt_one`.`order_ded_money`)
        from `lqkj_db`.`view_receipt_one`)                                                                 AS `sum_ded_money`,
       sum(`view_receipt_all`.`total_reced_money`)                                                         AS `sum_reced_money`,
       ((sum(`view_receipt_all`.`total_sal_money`) -
         (select sum(`view_receipt_one`.`order_ded_money`) from `lqkj_db`.`view_receipt_one`)) -
        sum(`view_receipt_all`.`total_reced_money`))                                                       AS `sum_rec_money`,
       (((sum(`view_receipt_all`.`total_sal_money`) -
          (select sum(`view_receipt_one`.`order_ded_money`) from `lqkj_db`.`view_receipt_one`)) -
         sum(`view_receipt_all`.`total_reced_money`)) -
        sum(`view_receipt_all`.`total_unmat_unrec_money`))                                                 AS `sum_mat_rec_money`,
       sum(`view_receipt_all`.`total_unmat_unrec_money`)                                                   AS `sum_unmat_unrec_money`
from (`lqkj_db`.`view_receipt_all`
         join `lqkj_db`.`view_receipt_one`);

