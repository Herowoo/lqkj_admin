create definer = lqkj@`%` trigger salesmandaily_his
    after delete
    on yw_report_salesman_daily
    for each row
BEGIN
INSERT INTO yw_report_salesman_daily_his SELECT * FROM yw_report_salesman_daily where id=old.id;
END;

