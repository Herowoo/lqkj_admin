create definer = lqkj@`%` view view_receipt as
select `view_receipt_one`.`cre_id`                                                                           AS `cre_id`,
       `view_receipt_one`.`cus_name`                                                                         AS `cus_name`,
       `view_receipt_one`.`ass_period`                                                                       AS `ass_period`,
       `view_receipt_one`.`order_id`                                                                         AS `order_id`,
       `view_receipt_one`.`order_detail_info`                                                                AS `order_detail_info`,
       `view_receipt_one`.`all_code_amo_money`                                                               AS `all_code_amo_money`,
       (ifnull(`view_receipt_two`.`all_code_amo_money`, '0') +
        ifnull(`view_receipt_three`.`all_code_amo_money`, '0'))                                              AS `reced_money`,
       (((`view_receipt_one`.`all_code_amo_money` - `view_receipt_one`.`order_ded_money`) -
         ifnull(`view_receipt_two`.`all_code_amo_money`, '0')) -
        ifnull(`view_receipt_three`.`all_code_amo_money`, '0'))                                              AS `unrec_money`,
       `view_receipt_one`.`mat_date`                                                                         AS `mat_date`,
       ((`view_receipt_one`.`all_code_amo_money` - `view_receipt_one`.`order_qua_deposit`) -
        `view_receipt_one`.`order_ded_money`)                                                                AS `mat_rec_money`,
       (case
            when (`view_receipt_one`.`exc_date` < 0) then (
                    ((`view_receipt_one`.`all_code_amo_money` - `view_receipt_one`.`order_ded_money`) -
                     ifnull(`view_receipt_two`.`all_code_amo_money`, '0')) - `view_receipt_one`.`order_qua_deposit`)
            else 0 end)                                                                                      AS `unmat_unrec_money`,
       (case
            when (`view_receipt_one`.`exc_date` > 0) then (
                    ((`view_receipt_one`.`all_code_amo_money` - `view_receipt_one`.`order_ded_money`) -
                     ifnull(`view_receipt_two`.`all_code_amo_money`, '0')) - `view_receipt_one`.`order_qua_deposit`)
            else 0 end)                                                                                      AS `mat_unrec_money`,
       (case
            when (`view_receipt_one`.`exc_date` < 0) then 0
            else `view_receipt_one`.`exc_date` end)                                                          AS `exc_date`,
       `view_receipt_one`.`bao_mat_date`                                                                     AS `bao_mat_date`,
       (case
            when (`view_receipt_one`.`bao_exc_date` < 0) then (`view_receipt_one`.`order_qua_deposit` -
                                                               ifnull(`view_receipt_three`.`all_code_amo_money`, '0'))
            else 0 end)                                                                                      AS `unmat_unrec_bao_money`,
       (case
            when (`view_receipt_one`.`bao_exc_date` > 0) then (`view_receipt_one`.`order_qua_deposit` -
                                                               ifnull(`view_receipt_three`.`all_code_amo_money`, '0'))
            else 0 end)                                                                                      AS `mat_unrec_bao_money`,
       (case
            when (`view_receipt_one`.`bao_exc_date` < 0) then 0
            else `view_receipt_one`.`bao_exc_date` end)                                                      AS `bao_exc_date`
from ((`lqkj_db`.`view_receipt_one` left join `lqkj_db`.`view_receipt_two` on ((`view_receipt_one`.`order_id` = `view_receipt_two`.`order_id`)))
         left join `lqkj_db`.`view_receipt_three`
                   on ((`view_receipt_one`.`order_id` = `view_receipt_three`.`order_id`)));

