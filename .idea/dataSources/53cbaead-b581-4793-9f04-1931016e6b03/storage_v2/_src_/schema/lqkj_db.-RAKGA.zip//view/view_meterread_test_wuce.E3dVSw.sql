create definer = lqkj@`%` view view_meterread_test_wuce as
select `a`.`id`                AS `id`,
       `a`.`insert_date`       AS `insert_date`,
       `a`.`Platform_Num`      AS `Platform_Num`,
       `a`.`Batch_Num`         AS `Batch_Num`,
       `a`.`Test_Result`       AS `Test_Result`,
       `a`.`Test_Value`        AS `Test_Value`,
       `a`.`Board_SN_Result`   AS `Board_SN_Result`,
       `a`.`Board_SN`          AS `Board_SN`,
       `a`.`Chip_mmid_Result`  AS `Chip_mmid_Result`,
       `a`.`Chip_mmid`         AS `Chip_mmid`,
       `a`.`Model_ID_Resut`    AS `Model_ID_Resut`,
       `a`.`Module_ID`         AS `Module_ID`,
       `a`.`Hw_Version_Result` AS `Hw_Version_Result`,
       `a`.`Hw_Version`        AS `Hw_Version`,
       `a`.`Fw_Version_Result` AS `Fw_Version_Result`,
       `a`.`Fw_Version`        AS `Fw_Version`,
       `a`.`Vendor_id_Result`  AS `Vendor_id_Result`,
       `a`.`Vendor_id`         AS `Vendor_id`,
       `a`.`prod_line`         AS `prod_line`
from `lqkj_db`.`yw_project_meterread_test_info` `a`
where exists(select 1 from `lqkj_db`.`yw_project_meterread_test_info_his` `b` where (`a`.`Board_SN` = `b`.`Board_SN`))
union all
select `lqkj_db`.`yw_project_meterread_test_info_his`.`id`                AS `id`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`insert_date`       AS `insert_date`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Platform_Num`      AS `Platform_Num`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Batch_Num`         AS `Batch_Num`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Test_Result`       AS `Test_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Test_Value`        AS `Test_Value`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Board_SN_Result`   AS `Board_SN_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Board_SN`          AS `Board_SN`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Chip_mmid_Result`  AS `Chip_mmid_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Chip_mmid`         AS `Chip_mmid`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Model_ID_Resut`    AS `Model_ID_Resut`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Module_ID`         AS `Module_ID`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Hw_Version_Result` AS `Hw_Version_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Hw_Version`        AS `Hw_Version`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Fw_Version_Result` AS `Fw_Version_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Fw_Version`        AS `Fw_Version`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Vendor_id_Result`  AS `Vendor_id_Result`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`Vendor_id`         AS `Vendor_id`,
       `lqkj_db`.`yw_project_meterread_test_info_his`.`prod_line`         AS `prod_line`
from `lqkj_db`.`yw_project_meterread_test_info_his`;

