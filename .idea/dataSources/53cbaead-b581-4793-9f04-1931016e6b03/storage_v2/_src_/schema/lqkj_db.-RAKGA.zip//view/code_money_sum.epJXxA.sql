create definer = lqkj@`%` view code_money_sum as
select `cus`.`cre_id`                                               AS `cre_id`,
       `cus`.`cus_name`                                             AS `cus_name`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_num`            AS `code_num`,
       `lqkj_db`.`yw_receivable_invoice_info`.`CODE`                AS `CODE`,
       sum(`lqkj_db`.`yw_receivable_invoice_info`.`code_amo_money`) AS `code_money`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_date`           AS `code_date`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_annex`          AS `code_annex`,
       `lqkj_db`.`yw_receivable_invoice_info`.`code_hand_date`      AS `code_hand_date`
from (`lqkj_db`.`yw_receivable_invoice_info`
         left join (select distinct `view_receipt_detail`.`cre_id`   AS `cre_id`,
                                    `view_receipt_detail`.`cus_name` AS `cus_name`,
                                    `view_receipt_detail`.`order_id` AS `order_id`
                    from `lqkj_db`.`view_receipt_detail`) `cus`
                   on ((`lqkj_db`.`yw_receivable_invoice_info`.`code_order_id` = `cus`.`order_id`)))
where (`lqkj_db`.`yw_receivable_invoice_info`.`code_state` = '1')
group by `lqkj_db`.`yw_receivable_invoice_info`.`code_num`;

