create definer = lqkj@`%` view view_payable_ledger as
select `lqkj_db`.`yw_payable_invoice_info`.`code_cre_id`    AS `code_cre_id`,
       `fac_info`.`fac_name`                                AS `fac_name`,
       `lqkj_db`.`yw_payable_invoice_info`.`CODE`           AS `CODE`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_pay_type`  AS `code_pay_type`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_num`       AS `code_num`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_date`      AS `code_date`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_amo_money` AS `code_amo_money`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_annex`     AS `code_annex`,
       `lqkj_db`.`yw_payable_invoice_info`.`code_hand_date` AS `code_hand_date`
from `lqkj_db`.`yw_payable_invoice_info`
         join `lqkj_db`.`yw_payable_factory_info` `fac_info`
where ((`lqkj_db`.`yw_payable_invoice_info`.`code_cre_id` = `fac_info`.`cre_id`) and
       (`lqkj_db`.`yw_payable_invoice_info`.`code_state` = '1'));

