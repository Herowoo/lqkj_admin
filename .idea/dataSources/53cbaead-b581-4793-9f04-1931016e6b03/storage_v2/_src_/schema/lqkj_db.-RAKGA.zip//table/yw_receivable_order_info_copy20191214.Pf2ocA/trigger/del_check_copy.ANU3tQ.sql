create definer = lqkj@`%` trigger del_check_copy
    before delete
    on yw_receivable_order_info_copy20191214
    for each row
BEGIN
INSERT INTO yw_receivable_order_info_copy SELECT * FROM yw_receivable_order_info where ord_id=old.ord_id;
END;

