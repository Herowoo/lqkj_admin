create definer = lqkj@`%` view view_flash_burn_wuce as
select `a`.`id`           AS `id`,
       `a`.`tran_date`    AS `tran_date`,
       `a`.`Board_SN`     AS `Board_SN`,
       `a`.`Platform_Num` AS `Platform_Num`,
       `a`.`prod_line`    AS `prod_line`,
       `a`.`Test_Result`  AS `Test_Result`,
       `a`.`Batch_Num`    AS `Batch_Num`,
       `a`.`chip_id`      AS `chip_id`
from `lqkj_db`.`yw_project_flash_burn_info` `a`
where exists(select 1 from `lqkj_db`.`yw_project_flash_burn_info_his` `b` where (`a`.`Board_SN` = `b`.`Board_SN`))
union all
select `lqkj_db`.`yw_project_flash_burn_info_his`.`id`           AS `id`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`tran_date`    AS `tran_date`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`Board_SN`     AS `Board_SN`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`Platform_Num` AS `Platform_Num`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`prod_line`    AS `prod_line`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`Test_Result`  AS `Test_Result`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`Batch_Num`    AS `Batch_Num`,
       `lqkj_db`.`yw_project_flash_burn_info_his`.`chip_id`      AS `chip_id`
from `lqkj_db`.`yw_project_flash_burn_info_his`;

