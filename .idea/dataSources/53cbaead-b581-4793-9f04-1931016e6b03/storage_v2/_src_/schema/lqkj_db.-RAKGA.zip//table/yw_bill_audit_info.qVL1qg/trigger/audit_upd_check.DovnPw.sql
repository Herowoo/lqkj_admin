create definer = lqkj@`%` trigger audit_upd_check
    before update
    on yw_bill_audit_info
    for each row
BEGIN
INSERT INTO yw_bill_audit_info_his SELECT * FROM yw_bill_audit_info where id=old.id;
END;

