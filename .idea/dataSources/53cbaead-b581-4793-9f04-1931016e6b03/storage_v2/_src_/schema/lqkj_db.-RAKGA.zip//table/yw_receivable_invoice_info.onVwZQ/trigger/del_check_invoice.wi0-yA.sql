create definer = lqkj@`%` trigger del_check_invoice
    before delete
    on yw_receivable_invoice_info
    for each row
BEGIN
INSERT INTO yw_receivable_invoice_info_copy SELECT * FROM yw_receivable_invoice_info where code_id=old.code_id;
END;

