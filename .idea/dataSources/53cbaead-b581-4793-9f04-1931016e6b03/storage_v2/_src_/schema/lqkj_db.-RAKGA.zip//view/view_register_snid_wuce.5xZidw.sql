create definer = lqkj@`%` view view_register_snid_wuce as
select `a`.`id`        AS `id`,
       `a`.`tran_date` AS `tran_date`,
       `a`.`order_id`  AS `order_id`,
       `a`.`spc_name`  AS `spc_name`,
       `a`.`plan_id`   AS `plan_id`,
       `a`.`pcb_sn`    AS `pcb_sn`,
       `a`.`model_id`  AS `model_id`,
       `a`.`gw_id`     AS `gw_id`,
       `a`.`win_id`    AS `win_id`,
       `a`.`prod_line` AS `prod_line`,
       `a`.`state`     AS `state`
from `lqkj_db`.`yw_project_snid_detail` `a`
where exists(select `c`.`id`,
                    `c`.`tran_date`,
                    `c`.`order_id`,
                    `c`.`spc_name`,
                    `c`.`plan_id`,
                    `c`.`pcb_sn`,
                    `c`.`model_id`,
                    `c`.`gw_id`,
                    `c`.`win_id`,
                    `c`.`prod_line`,
                    `c`.`state`
             from `lqkj_db`.`yw_project_snid_detail_his` `c`
             where (`a`.`pcb_sn` = `c`.`pcb_sn`))
union all
select `lqkj_db`.`yw_project_snid_detail_his`.`id`        AS `id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`tran_date` AS `tran_date`,
       `lqkj_db`.`yw_project_snid_detail_his`.`order_id`  AS `order_id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`spc_name`  AS `spc_name`,
       `lqkj_db`.`yw_project_snid_detail_his`.`plan_id`   AS `plan_id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`pcb_sn`    AS `pcb_sn`,
       `lqkj_db`.`yw_project_snid_detail_his`.`model_id`  AS `model_id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`gw_id`     AS `gw_id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`win_id`    AS `win_id`,
       `lqkj_db`.`yw_project_snid_detail_his`.`prod_line` AS `prod_line`,
       `lqkj_db`.`yw_project_snid_detail_his`.`state`     AS `state`
from `lqkj_db`.`yw_project_snid_detail_his`;

