create definer = lqkj@`%` view view_receipt_all as
select `view_receipt`.`cre_id`                                                                 AS `cre_id`,
       `view_receipt`.`cus_name`                                                               AS `cus_name`,
       sum(`view_receipt`.`all_code_amo_money`)                                                AS `total_sal_money`,
       sum(`view_receipt`.`reced_money`)                                                       AS `total_reced_money`,
       sum(`view_receipt`.`unrec_money`)                                                       AS `total_unrec_money`,
       (sum(`view_receipt`.`mat_unrec_money`) +
        sum(`view_receipt`.`mat_unrec_bao_money`))                                             AS `total_mat_unrec_money`,
       (sum(`view_receipt`.`unmat_unrec_money`) +
        sum(`view_receipt`.`unmat_unrec_bao_money`))                                           AS `total_unmat_unrec_money`
from `lqkj_db`.`view_receipt`
group by `view_receipt`.`cre_id`;

