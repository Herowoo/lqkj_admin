create definer = lqkj@`%` view view_bill_select as
select `tb_head_hard`.`id`            AS `id`,
       `tb_head_hard`.`head_id`       AS `head_id`,
       `tb_head_hard`.`proid`         AS `proid`,
       `tb_head_hard`.`order_type`    AS `order_type`,
       `tb_head_hard`.`insert_time`   AS `insert_time`,
       `tb_head_hard`.`order_number`  AS `order_number`,
       `tb_head_hard`.`plan_number`   AS `plan_number`,
       `tb_head_hard`.`customer_name` AS `customer_name`,
       `tb_head_hard`.`product_name`  AS `product_name`,
       `tb_head_hard`.`specification` AS `specification`,
       `tb_head_hard`.`quantity`      AS `quantity`,
       `tb_head_hard`.`delivery_date` AS `delivery_date`,
       `tb_head_hard`.`salesman`      AS `salesman`,
       `tb_head_hard`.`area`          AS `area`,
       `tb_head_hard`.`special_claim` AS `special_claim`,
       `tb_head_hard`.`special_care`  AS `special_care`,
       `tb_head_hard`.`state`         AS `state`,
       `tb_head_hard`.`require_value` AS `require_value`,
       `tb_head_hard`.`hardware`      AS `hardware`,
       `tb_soft`.`software`           AS `software`
from ((select `view_bill_select_tmp`.`id`            AS `id`,
              `view_bill_select_tmp`.`head_id`       AS `head_id`,
              `view_bill_select_tmp`.`proid`         AS `proid`,
              `view_bill_select_tmp`.`order_type`    AS `order_type`,
              `view_bill_select_tmp`.`insert_time`   AS `insert_time`,
              `view_bill_select_tmp`.`order_number`  AS `order_number`,
              `view_bill_select_tmp`.`plan_number`   AS `plan_number`,
              `view_bill_select_tmp`.`customer_name` AS `customer_name`,
              `view_bill_select_tmp`.`product_name`  AS `product_name`,
              `view_bill_select_tmp`.`specification` AS `specification`,
              `view_bill_select_tmp`.`quantity`      AS `quantity`,
              `view_bill_select_tmp`.`delivery_date` AS `delivery_date`,
              `view_bill_select_tmp`.`salesman`      AS `salesman`,
              `view_bill_select_tmp`.`area`          AS `area`,
              `view_bill_select_tmp`.`special_claim` AS `special_claim`,
              `view_bill_select_tmp`.`special_care`  AS `special_care`,
              `view_bill_select_tmp`.`state`         AS `state`,
              `view_bill_select_tmp`.`require_value` AS `require_value`,
              if((`tb_tmphard`.`num` > 0), '有', '无') AS `hardware`
       from (`lqkj_db`.`view_bill_select_tmp`
                left join (select `lqkj_db`.`yw_bill_hardware_version_confirm`.`head_id` AS `head_id`, count(1) AS `num`
                           from `lqkj_db`.`yw_bill_hardware_version_confirm`
                           group by `lqkj_db`.`yw_bill_hardware_version_confirm`.`head_id`) `tb_tmphard`
                          on ((`view_bill_select_tmp`.`head_id` = `tb_tmphard`.`head_id`)))) `tb_head_hard`
         join (select `view_bill_select_tmp`.`head_id`       AS `head_id`,
                      if((`tb_tmpsoft`.`num` > 0), '有', '无') AS `software`
               from (`lqkj_db`.`view_bill_select_tmp`
                        left join (select `lqkj_db`.`yw_bill_software_version_confirm`.`head_id` AS `head_id`,
                                          count(1)                                               AS `num`
                                   from `lqkj_db`.`yw_bill_software_version_confirm`
                                   group by `lqkj_db`.`yw_bill_software_version_confirm`.`head_id`) `tb_tmpsoft`
                                  on ((`view_bill_select_tmp`.`head_id` = `tb_tmpsoft`.`head_id`)))) `tb_soft`)
where (`tb_head_hard`.`head_id` = `tb_soft`.`head_id`);

